#!/usr/bin/python3
"""Bounded, separately authorized strace diagnostic; never formal benchmark data."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import time

BASE = Path(__file__).resolve().parent


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def emit(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def argv_for(plan, label, command):
    work = Path(plan["work_root"])
    argv = ["/usr/bin/bwrap", "--unshare-user", "--unshare-pid", "--die-with-parent",
            "--tmpfs", "/", "--dir", "/workspace", "--bind", str(work / "repo"), "/workspace",
            "--bind", str(work / "home"), "/home/threadmill", "--bind", str(work / "tmp"), "/tmp"]
    for path in plan["bwrap_readonly_paths"]:
        argv += ["--ro-bind-try", path, path]
    argv += ["--dev", "/dev", "--proc", "/proc", "--chdir", "/workspace", "--",
             "/usr/bin/strace", "-d", *plan["strace_flags"], "-o", "/tmp/.tmtrace-" + label,
             "--", "bash", "-c", command]
    return argv


def group_exists(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False


def kill_group(pgid):
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def capture(argv, environment, label, timeout, deadline, records):
    """Only wait for our own child. The outer supervisor alone reaps adoptees."""
    allowed = min(timeout, deadline - time.monotonic())
    require(allowed > 0, "total diagnostic budget exhausted")
    record = {"label": label, "argv": argv, "started_utc": now(), "timeout_seconds": allowed}
    records.append(record)
    log_path = BASE / (label + ".log")
    process = None
    with log_path.open("xb") as log:
        try:
            process = subprocess.Popen(argv, env=environment, stdin=subprocess.DEVNULL,
                                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, process_group=0)
            record["pid"] = process.pid
            os.set_blocking(process.stdout.fileno(), False)
            stop = time.monotonic() + allowed
            exited_at = None
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                while selector.get_map():
                    if time.monotonic() >= stop:
                        raise TimeoutError(label + ": subprocess timeout")
                    if process.poll() is not None:
                        if exited_at is None:
                            exited_at = time.monotonic()
                        if time.monotonic() - exited_at >= 1:
                            raise TimeoutError(label + ": inherited output pipe did not close")
                    for key, _ in selector.select(min(0.05, max(0, stop - time.monotonic()))):
                        data = os.read(key.fd, 65536)
                        if data:
                            log.write(data)
                            log.flush()
                        else:
                            selector.unregister(key.fileobj)
                record["exit_code"] = process.wait(timeout=max(0.001, stop - time.monotonic()))
            settle = min(deadline, time.monotonic() + 1)
            while group_exists(process.pid) and time.monotonic() < settle:
                time.sleep(0.01)
            require(not group_exists(process.pid), label + ": process group remains after foreground exit")
        except BaseException as error:
            record["failure"] = repr(error)
            raise
        finally:
            if process is not None:
                if process.poll() is None or group_exists(process.pid):
                    kill_group(process.pid)
                try:
                    record["exit_code"] = process.wait(timeout=5)
                finally:
                    while True:
                        try:
                            data = os.read(process.stdout.fileno(), 65536)
                        except BlockingIOError:
                            break
                        if not data:
                            break
                        log.write(data)
                    process.stdout.close()
                record["group_present_at_return"] = group_exists(process.pid)
            record["ended_utc"] = now()
            log.flush()
            record["log_sha256"] = sha(log_path)
    text = log_path.read_bytes()
    record["ptrace_error"] = b"ptrace(PTRACE_" in text
    require(record["exit_code"] == 0 and not record["ptrace_error"], label + ": first nonzero exit or ptrace error; stopping")


def validate(expected_sha):
    path = BASE / "preregistration.json"
    require(sha(path) == expected_sha, "preregistration SHA256 differs")
    plan = json.loads(path.read_text())
    require(os.getuid() == plan["uid"] and os.geteuid() == plan["uid"], "run as original uid, not root")
    for path, expected in plan["files_sha256"].items():
        require(sha(path) == expected, "frozen source/input differs: " + path)
    private = BASE / "environment.json"
    require(private.stat().st_mode & 0o777 == 0o600, "private environment must have mode 0600")
    require(sha(private) == plan["private_environment_sha256"], "private environment differs")
    require(not (BASE / "run-status.json").exists(), "diagnostic already started; no automatic restart")
    require(not any(Path(plan["work_root"]).iterdir()), "work directory must be fresh")
    fixture = plan["fixture"]
    git = ["/usr/bin/git", "-c", "safe.directory=" + fixture, "-C", fixture]
    git_environment = {"PATH": "/usr/bin:/bin", "GIT_OPTIONAL_LOCKS": "0"}
    head = subprocess.check_output(git + ["rev-parse", "HEAD"], env=git_environment, timeout=5).decode().strip()
    dirty = subprocess.check_output(git + ["status", "--porcelain"], env=git_environment, timeout=5).strip()
    require(head == plan["fixture_commit"] and not dirty, "frozen fixture identity/cleanliness differs")
    for item in plan["invocations"]:
        require(argv_for(plan, item["label"], item["command"]) == item["argv"], "registered argv differs")
    return plan, json.loads(private.read_text())


def execute(plan, environment):
    status = {"started_utc": now(), "formal": False, "records": [], "outcome": "incomplete",
              "subreaper_owner": "external supervisor only", "registered_max_seconds": 90}
    # This exclusive marker makes interrupted or failed attempts non-repeatable.
    emit(BASE / "run-status.json", status)
    deadline = time.monotonic() + plan["total_seconds"]

    def interrupted(signum, _frame):
        raise InterruptedError("received signal " + str(signum))

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        work = Path(plan["work_root"])
        setup_env = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "GIT_OPTIONAL_LOCKS": "0"}
        for label, argv in plan["setup_commands"]:
            capture(argv, setup_env, label, 10, deadline, status["records"])
        for name in ("home", "tmp"):
            (work / name).mkdir(mode=0o700)
        operation = plan["initial_write"]
        (work / "repo" / operation["path"]).write_text(operation["content"])
        for item in plan["invocations"]:
            if time.monotonic() >= deadline:
                status["outcome"] = "budget_exhausted_without_observed_failure"
                break
            label = item["label"]
            trace = work / "tmp" / (".tmtrace-" + label)
            descriptor = os.open(trace, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            os.close(descriptor)
            print(json.dumps({"starting": label, "formal": False}), flush=True)
            try:
                capture(item["argv"], environment, label, item["timeout_seconds"], deadline, status["records"])
            finally:
                status["records"][-1]["trace"] = str(trace)
                status["records"][-1]["trace_sha256"] = sha(trace)
        else:
            status["outcome"] = "invocation_limit_reached_without_observed_failure"
    except BaseException as error:
        status["outcome"] = "stopped_on_first_failure"
        status["failure"] = repr(error)
        raise
    finally:
        status["ended_utc"] = now()
        temporary = BASE / "run-status.tmp"
        temporary.write_text(json.dumps(status, indent=2) + "\n")
        temporary.replace(BASE / "run-status.json")
        print(json.dumps({"outcome": status["outcome"], "completed_records": len(status["records"])}), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registration-sha256", required=True)
    parser.add_argument("--execute", action="store_true", help="requires root-approved sole hardware window and tested outer supervisor")
    args = parser.parse_args()
    plan, environment = validate(args.registration_sha256)
    if args.execute:
        execute(plan, environment)
    else:
        print(json.dumps({"static_identity": "passed", "planned_warmups": 4, "max_vet_invocations": 128,
                          "max_seconds": 90, "workload_executed": False}))


if __name__ == "__main__":
    main()
