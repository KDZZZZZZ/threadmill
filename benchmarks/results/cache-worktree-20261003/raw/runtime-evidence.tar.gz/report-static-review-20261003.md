本轮为五轴静态审查，结论是：已审范围内无剩余必改项；不等于完整报告验收通过。历史 OverlayFS 新表、原始证据归档及对应占位明确排除，完成后须单独审查。

记录时间：2026-10-03 15:54:36 UTC。报告路径：`/home/oops/repo/threadmill-cache-report/docs/threadmill-vs-pi-worktree-performance.md`。

- 审查结束时读取的报告 SHA-256：`6eed0586470fd26782ed62bd4c2995cfc162d4bd14bbfdb3e9fac60dfedb563d`。
- 本次落盘时当前报告 SHA-256：`595da8ebaad6e93a551b480a61c6d7279c0c8475b53c5c737a57e82c2445fe39`。后续两处文字精确化已由 root 确认采纳；本次仅计算当前摘要并记录既有结论，没有重新审查全文。

数值核对读取报告、小 CSV、审计摘要和保存的 benchstat 文本，未读取大原始 JSON 或 gzip 归档，未重跑审计程序、测试、编译、容器或工作负载。

560 个显示数值逐项按三位小数核对，差异为零：主矩阵 480 个，包括两种 fixture 各八档的 wall/commands/s 共 96 个、peak/retained 共 96 个，以及 write/fork/collect P50/P95 共 288 个；共享 cwd 两种 fixture 各八档的 wall、commands/s、write P95、peak、retained 共 80 个。来源为结果目录的 `primary-metrics.csv` 与 `reference-metrics.csv`。这一核对验证报告与 CSV 的一致性，没有独立重算原始运行内的分位数。

另核对 `pytest-audit.json` 的四组 wall 中位数、600 次预期与实际回放、93.74% 时间加权命中率、lookup/store 耗时、14.519 秒净 wall 收益，以及保存的 `benchstat.txt` 中 +42.77% / +44.91%、p=0.000、n=10。报告未把脚本 oracle、零 unexpected replay 或零验证样本写成 fresh shadow audit 零误命中。

五轴结论：

- 正确性：上述数值一致；Go 文字区分本次已证实的 ESRCH 错分与原两个 errno 未知的失败，不把未复现或回收修正说成修复，也没有给未完成 Go 矩阵计算正式收益。
- 可读性：pytest 与 Go 分节，失败及诊断限制明确。root 已采纳“修改 strace.c 并重建诊断版本”，避免暗示仅编译一个编译单元。
- 架构：主矩阵 external 与 Harbor ExternalWorkspaceIsolation 的范围分开，缓存、追踪、heavy threshold、内存准入及 shared network 的测量设置有披露。root 已采纳 bwrap 文件系统、用户和 PID 隔离的精确表述。
- 安全性：没有把配置权限、离线 AppArmor 解析、root 安装预检写成真实任务 USER 准入成功；本轮没有发现报告中的秘密材料。没有重新验证容器能力或宿主策略。
- 性能：wall、逻辑宽度、命令吞吐、采样峰值、retained 和分位数范围分开；容量规则及 IPython/external/576 中断与补测限制清楚，没有通用性能或 shadow 审计外推。

唯一必改项已修：简历段原“保存后物理增量增加约 12.1 倍”与 CSV 比值 12.09158 不符，已改为“保存后物理增量约为 Pi 的 12.1 倍”，并在审查结束时确认。其余两处可选精确化见上文，root 已确认采纳。

I1：root 负责最终接受；I2：本审查只读报告和小证据，本次仅新增本记录；I3：560 格一致性、审计摘要核对与原始测量验证的范围分别说明。历史表和归档占位不计入通过，未来新增内容不继承本次审查结论。
