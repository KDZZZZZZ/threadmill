#!/usr/bin/env python3
"""Public CLI regressions. No benchmark, Go build, or production harness import."""

import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest


SUPERVISOR = Path(os.environ.get("REAPER_UNDER_TEST", Path(__file__).with_name("supervise.py")))
FIXTURE = r'''
import json, os, pathlib, signal, sys, time
case, directory = sys.argv[1:]
root = pathlib.Path(directory)
signal.signal(signal.SIGTERM, signal.SIG_IGN)
signal.signal(signal.SIGINT, signal.SIG_IGN)
def identity():
    fields = pathlib.Path(f"/proc/{os.getpid()}/stat").read_text().rpartition(")")[2].split()
    return {"pid": os.getpid(), "start_ticks": int(fields[19])}
def publish(name, value):
    temporary = root / (name + ".tmp")
    temporary.write_text(json.dumps(value))
    temporary.replace(root / name)
count = 48 if case == "continuous" else 3
for index in range(count):
    child = os.fork()
    if child == 0:
        os.setsid()
        if os.fork() != 0:
            os._exit(0)
        publish(f"orphan-{index}.json", identity())
        if case == "continuous":
            os._exit(0)
        while True:
            time.sleep(0.05)
    os.waitpid(child, 0)
while len(list(root.glob("orphan-*.json"))) != count:
    time.sleep(0.01)
publish("ready.json", identity())
while not (root / "release").exists():
    time.sleep(0.01)
if case == "killed":
    os.kill(os.getpid(), signal.SIGKILL)
os._exit(137 if case == "failure" else 0)
'''


def same_process(identity):
    try:
        fields = Path(f"/proc/{identity['pid']}/stat").read_text().rpartition(")")[2].split()
        return int(fields[19]) == identity["start_ticks"]
    except (FileNotFoundError, ProcessLookupError):
        return False


def until(predicate, timeout=5):
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        if predicate():
            return True
        time.sleep(0.01)
    return False


class SupervisorTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="continuous-reaper-test-")
        self.root = Path(self.temporary.name)
        self.proof = self.root / "proof.json"
        self.process = None
        self.sibling = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(60)"],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )

    def tearDown(self):
        # Even a broken candidate must not leave this test's processes running.
        if os.environ.get("REAPER_EVIDENCE_DIR") and self.proof.exists():
            target = Path(os.environ["REAPER_EVIDENCE_DIR"]) / (self._testMethodName + ".json")
            with target.open("x") as output:
                output.write(self.proof.read_text())
        identities = self.identities()
        ready = self.root / "ready.json"
        if ready.exists():
            identities.append(json.loads(ready.read_text()))
        for identity in identities:
            if same_process(identity):
                try:
                    fd = os.pidfd_open(identity["pid"])
                    try:
                        if same_process(identity):
                            signal.pidfd_send_signal(fd, signal.SIGKILL)
                    finally:
                        os.close(fd)
                except ProcessLookupError:
                    pass
        if self.process is not None:
            try:
                self.process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
        self.sibling.terminate()
        self.sibling.wait(timeout=5)
        self.temporary.cleanup()

    def identities(self):
        return [json.loads(path.read_text()) for path in self.root.glob("orphan-*.json")]

    def launch(self, case):
        self.process = subprocess.Popen(
            [sys.executable, str(SUPERVISOR), "--evidence", str(self.proof), "--",
             sys.executable, "-c", FIXTURE, case, str(self.root)],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        self.assertTrue(until(lambda: (self.root / "ready.json").exists()),
                        "fixture did not become ready through the public supervisor CLI")
        return json.loads((self.root / "ready.json").read_text())

    def finish(self, expected):
        self.assertEqual(self.process.wait(timeout=10), expected)
        proof = json.loads(self.proof.read_text())
        self.assertEqual(proof["exit_code"], expected)
        self.assertTrue(proof["cleanup"]["clean"], proof)
        self.assertEqual(proof["cleanup"]["remaining"], [])
        self.assertEqual(proof["cleanup"]["errors"], [])
        self.assertFalse(any(same_process(identity) for identity in self.identities()))
        self.assertIsNone(self.sibling.poll(), "supervisor killed an unrelated sibling")
        self.assertIn(proof["runner"]["returncode"], (0, 137, -signal.SIGKILL))
        return proof

    def test_reaps_double_fork_setsid_orphans_while_runner_is_alive(self):
        runner = self.launch("continuous")
        identities = self.identities()
        self.assertEqual(len(identities), 48)
        self.assertTrue(until(lambda: not any(same_process(item) for item in identities), 2),
                        "exited adopted descendants were not promptly reaped while runner stayed alive")
        self.assertIsNone(self.process.poll())
        self.assertTrue(same_process(runner), "the foreground runner exited during the prompt-reap check")
        children = Path(f"/proc/{self.process.pid}/task/{self.process.pid}/children").read_text().split()
        self.assertEqual(children, [str(runner["pid"])])
        (self.root / "release").touch()
        proof = self.finish(0)
        self.assertEqual(proof["runner"]["returncode"], 0)
        expected = {(item["pid"], item["start_ticks"]) for item in identities}
        actual = {(item["pid"], item["start_ticks"]) for item in proof["normal_reaped"]}
        self.assertEqual(actual, expected)
        self.assertTrue(all(item["returncode"] == 0 for item in proof["normal_reaped"]))
        self.assertEqual(proof["cleanup"]["live_descendants"], [])
        self.assertEqual(proof["cleanup"]["signals"], [])

    def assert_forced_cleanup(self, proof):
        identities = {(item["pid"], item["start_ticks"]) for item in self.identities()}
        reaped = {(item["pid"], item["start_ticks"]) for item in proof["cleanup"]["reaped"]}
        self.assertEqual(reaped, identities)
        self.assertTrue(all(item["returncode"] == -signal.SIGKILL
                            for item in proof["cleanup"]["reaped"]))
        self.assertEqual({(item["pid"], item["start_ticks"])
                          for item in proof["cleanup"]["live_descendants"]}, identities)
        signals = proof["cleanup"]["signals"]
        for pid, start in identities:
            self.assertEqual([item["signal"] for item in signals
                              if (item["pid"], item["start_ticks"]) == (pid, start)],
                             [signal.SIGTERM, signal.SIGKILL])

    def test_runner_exit_137_is_preserved_and_live_orphans_are_cleaned(self):
        self.launch("failure")
        (self.root / "release").touch()
        proof = self.finish(137)
        self.assertEqual(proof["runner"]["returncode"], 137)
        self.assertEqual(proof["cleanup"]["trigger"], "runner_exit")
        self.assert_forced_cleanup(proof)

    def test_zero_runner_with_live_orphans_is_a_supervision_failure(self):
        self.launch("leftovers")
        (self.root / "release").touch()
        proof = self.finish(70)
        self.assertEqual(proof["runner"]["returncode"], 0)
        self.assert_forced_cleanup(proof)

    def test_sigkill_of_runner_is_reported_as_137(self):
        self.launch("killed")
        (self.root / "release").touch()
        proof = self.finish(137)
        self.assertEqual(proof["runner"]["returncode"], -signal.SIGKILL)
        self.assert_forced_cleanup(proof)

    def assert_signal_cleanup(self, sig):
        self.launch("signal")
        os.kill(self.process.pid, sig)
        proof = self.finish(128 + sig)
        self.assertEqual(proof["stop_signal"], sig)
        self.assertEqual(proof["cleanup"]["trigger"], "signal")
        self.assertEqual(proof["runner"]["returncode"], -signal.SIGKILL)
        self.assert_forced_cleanup(proof)

    def test_sigterm_cleans_detached_descendants(self):
        self.assert_signal_cleanup(signal.SIGTERM)

    def test_sigint_cleans_detached_descendants(self):
        self.assert_signal_cleanup(signal.SIGINT)


if __name__ == "__main__":
    unittest.main(verbosity=2)
