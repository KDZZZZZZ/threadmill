# Continuous child reaping for the external continuation

`supervise.py` is a single-threaded Linux parent for exactly one foreground
runner. It owns `PR_SET_CHILD_SUBREAPER`, polls every 20 ms, and drains exited
adopted children with `waitid(WEXITED | WNOHANG | WNOWAIT)` followed by an exact
`waitpid`. It records PID/starttime and exit status before reaping. Only the
runner's `Popen` may reap the runner, preserving both explicit exit 137 and
signal termination (`returncode=-9`, shell exit 137).

This is a new outer orchestration method. It must be registered separately from
the earlier end-only reaper. It does not change cwd, environment, cgroups,
resource limits, scheduling policy, the frozen b839 harness, or measured code.
The launcher supplies the intended cwd/environment. Evidence records the polling
interval and actual monotonic start/end times for supervision and cleanup.

## Launch contract

The foreground runner must not enable an inner subreaper or detach and return
before its work finishes. **Do not wrap the old continuation `run.py` unchanged:**
its inner subreaper would capture orphans before this supervisor can reap them.
Use a new separately registered orchestration file without inner subreaper
ownership, or invoke a frozen benchmark harness command directly.

After root review and registration, the exact supervisor argv prefix is:

```text
/usr/bin/python3 /home/oops/evals/threadmill-cache-bench/continuous-reaper-validation/supervise.py --evidence /NEW-OUTPUT/supervisor.json -- /usr/bin/python3 /NEW-OUTPUT/run.py --run
```

Replace only the new output/runner paths and registered runner arguments. The
evidence path must not exist; it is exclusively reserved before launching.
Detach the **supervisor**, using `subprocess.Popen(..., start_new_session=True)`
with the registered cwd, unchanged environment, stdin `/dev/null`, and output
redirected to a new log. The supervisor's sole `Popen(command)` inherits those
settings. Do not add resource or cgroup settings. Track the supervisor PID and
starttime, send it TERM/INT for cancellation, and consume its exit and evidence.
This document is a launch contract; no benchmark was launched for validation.

## Evidence and exit rules

- `normal_reaped` contains exited adopted processes reaped during foreground
  execution or its final drain. Their presence alone is not a leak or failure.
- `cleanup.live_descendants` contains still-live adopted processes encountered
  after runner exit, cancellation, or supervisor error. `cleanup.reaped` records
  exits during cleanup. The foreground runner has its own final return code.
- Cleanup signals only direct/adopted children after opening a pidfd and checking
  PID/starttime and `ppid == supervisor`. Parents' exit exposes further adopted
  children. Each gets TERM once, then KILL after the shared two-second TERM
  window; a further five-second bound includes killing and reaping. A child
  first adopted during KILL phase receives TERM then KILL immediately.
- `cleanup.clean` requires no remaining children and no signal errors. A runner
  returning zero with live leftovers, a supervisor error, or failed cleanup
  yields 70. A runner's nonzero status remains nonzero unchanged (negative signal
  status maps to 128 + signal). Supervisor TERM/INT yields 143/130. Always inspect
  cleanup evidence even when the runner failed.
- An ordinary launch error is recorded as `error`, with no runner, clean empty
  cleanup, and exit 70. A signaling error or cleanup timeout leaves a non-clean
  proof with error/remaining identities. An unavailable proof or `complete`
  absent/false is never successful validation.
- SIGKILL of the supervisor cannot run Python cleanup. Its reserved evidence
  file can remain empty, and descendants can survive. This limitation is
  unchanged; an uncatchable kill is not claimed safe. Unreadable `/proc` or an
  unrecoverable cleanup exception also prevents complete proof.

## Focused validation

Run from this directory: `python3 -m unittest -v test_supervise`.

Six tests use only Python subprocesses through the public command line. They
cover 48 setsid/double-fork exits disappearing while the foreground stays alive;
explicit exit 137; SIGKILL-derived 137; TERM and INT; and live leftovers after a
zero runner exit. Cleanup fixtures ignore TERM. Every case checks that unrelated
sibling processes survive and saved descendant PID/starttime identities vanish.
`red-end-only.log` records the decisive regression failing when only the live
reaping call is removed in a temporary copy. The candidate passes all tests.
Per-case proofs and exact file hashes are indexed by `validation.json`.

No frozen files, earlier evidence, Go builds, benchmark/reproduction commands,
or measurement rows are changed or executed by this validation.

## Sources and review

The Linux subreaper flag is not inherited by forked children, and orphaned
descendants are adopted by the nearest living subreaper:
[PR_SET_CHILD_SUBREAPER](https://man7.org/linux/man-pages/man2/PR_SET_CHILD_SUBREAPER.2const.html).
WNOWAIT leaves a terminated child available for its later exact wait:
[waitid](https://man7.org/linux/man-pages/man2/waitpid.2.html).
The foreground status belongs to
[Python Popen](https://docs.python.org/3/library/subprocess.html#subprocess.Popen.poll),
and signals use
[pidfd_send_signal](https://man7.org/linux/man-pages/man2/pidfd_send_signal.2.html).

Five-axis author review: correctness is exercised through the public CLI and an
end-only regression; the implementation uses one thread and standard-library
functions; orchestration is external to the frozen harness; signals require
owned PID/starttime and pidfd; normal polling does no host process-tree scan.
This is author review, with root retaining independent acceptance authority.
