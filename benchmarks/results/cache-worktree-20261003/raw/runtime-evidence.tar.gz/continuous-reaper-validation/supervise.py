#!/usr/bin/env python3
"""Linux supervisor for one foreground runner; never execute through a shell."""

import argparse
import ctypes
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time


POLL_SECONDS = 0.02
TERM_SECONDS = 2.0
KILL_SECONDS = 5.0


def process_identity(pid):
    try:
        fields = Path(f"/proc/{pid}/stat").read_text().rpartition(")")[2].split()
    except (FileNotFoundError, ProcessLookupError):
        return None
    return {"pid": pid, "start_ticks": int(fields[19]), "ppid": int(fields[1]),
            "pgid": int(fields[2]), "sid": int(fields[3]), "state": fields[0]}


def owned_children():
    # This supervisor is single-threaded. Orphans are adopted by this thread.
    pids = Path(f"/proc/self/task/{os.getpid()}/children").read_text().split()
    children = [process_identity(int(pid)) for pid in pids]
    return [child for child in children if child and child["ppid"] == os.getpid()]


def enable_subreaper():
    if not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        raise RuntimeError("Linux pidfd support is required")
    libc = ctypes.CDLL(None, use_errno=True)
    libc.prctl.argtypes = [ctypes.c_int] + [ctypes.c_ulong] * 4
    libc.prctl.restype = ctypes.c_int
    if libc.prctl(36, 1, 0, 0, 0) != 0:  # PR_SET_CHILD_SUBREAPER
        error = ctypes.get_errno()
        raise OSError(error, os.strerror(error))
    signal.signal(signal.SIGCHLD, signal.SIG_DFL)


def reap_exited(runner, records):
    while True:
        try:
            event = os.waitid(os.P_ALL, 0, os.WEXITED | os.WNOHANG | os.WNOWAIT)
        except ChildProcessError:
            return
        if event is None:
            return
        if runner is not None and runner.returncode is None and event.si_pid == runner.pid:
            # Popen alone owns the foreground status. Never waitpid it ourselves.
            runner.wait()
            continue
        identity = process_identity(event.si_pid)
        if identity is None or identity["ppid"] != os.getpid():
            raise RuntimeError(f"cannot identify waitable adopted child {event.si_pid}")
        _, status = os.waitpid(event.si_pid, 0)
        records.append({**identity, "wait_status": status,
                        "returncode": os.waitstatus_to_exitcode(status),
                        "waitid_code": event.si_code, "waitid_status": event.si_status,
                        "reaped_monotonic_ns": time.monotonic_ns()})


def signal_owned(identity, sig):
    try:
        fd = os.pidfd_open(identity["pid"])
    except ProcessLookupError:
        return False
    try:
        current = process_identity(identity["pid"])
        if (current is None or current["start_ticks"] != identity["start_ticks"]
                or current["ppid"] != os.getpid()):
            return False
        signal.pidfd_send_signal(fd, sig)
        return True
    except ProcessLookupError:
        return False
    finally:
        os.close(fd)


def cleanup_children(runner, trigger):
    proof = {"trigger": trigger, "live_descendants": [], "signals": [],
             "reaped": [], "remaining": [], "errors": [], "clean": False,
             "started_monotonic_ns": time.monotonic_ns()}
    observed = set()
    attempted = set()
    term_deadline = time.monotonic() + TERM_SECONDS
    kill_deadline = term_deadline + KILL_SECONDS
    while True:
        reap_exited(runner, proof["reaped"])
        children = owned_children()
        if not children:
            break
        for child in children:
            if child["state"] == "Z":
                continue
            key = (child["pid"], child["start_ticks"])
            if key not in observed:
                observed.add(key)
                if runner is None or runner.returncode is not None or child["pid"] != runner.pid:
                    proof["live_descendants"].append(child)
            # Killing a parent exposes further adopted children on the next pass.
            # Each new child receives TERM, even if discovered during KILL phase.
            signals = [signal.SIGTERM]
            if time.monotonic() >= term_deadline:
                signals.append(signal.SIGKILL)
            for sig in signals:
                attempt = (*key, int(sig))
                if attempt in attempted:
                    continue
                attempted.add(attempt)
                try:
                    if signal_owned(child, sig):
                        proof["signals"].append({**child, "signal": int(sig),
                                                 "sent_monotonic_ns": time.monotonic_ns()})
                except OSError as error:
                    proof["errors"].append(f"signal {int(sig)} to {key}: {error}")
        if time.monotonic() >= kill_deadline:
            break
        time.sleep(POLL_SECONDS)
    reap_exited(runner, proof["reaped"])
    proof["remaining"] = owned_children()
    proof["clean"] = not proof["remaining"] and not proof["errors"]
    proof["finished_monotonic_ns"] = time.monotonic_ns()
    return proof


def supervise(command):
    proof = {"schema": 1, "command": command, "started_monotonic_ns": time.monotonic_ns(),
             "supervisor": process_identity(os.getpid()), "subreaper": False,
             "poll_seconds": POLL_SECONDS, "term_seconds": TERM_SECONDS,
             "kill_seconds": KILL_SECONDS, "runner": None,
             "normal_reaped": [], "stop_signal": None, "error": None}
    runner = None

    def stop(sig, _frame):
        if proof["stop_signal"] is None:
            proof["stop_signal"] = sig

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    try:
        enable_subreaper()
        proof["subreaper"] = True
        runner = subprocess.Popen(command)
        proof["runner"] = process_identity(runner.pid)
        while runner.poll() is None and proof["stop_signal"] is None:
            reap_exited(runner, proof["normal_reaped"])
            if runner.returncode is None and proof["stop_signal"] is None:
                time.sleep(POLL_SECONDS)
        reap_exited(runner, proof["normal_reaped"])
    except BaseException as error:
        proof["error"] = f"{type(error).__name__}: {error}"
    finally:
        trigger = "signal" if proof["stop_signal"] else "error" if proof["error"] else "runner_exit"
        proof["cleanup"] = cleanup_children(runner, trigger)
        if runner is not None:
            runner.poll()
            proof["runner"]["returncode"] = runner.returncode

    if proof["stop_signal"]:
        code = 128 + proof["stop_signal"]
    elif runner is not None and runner.returncode:
        code = runner.returncode if runner.returncode > 0 else 128 - runner.returncode
    elif proof["error"] or not proof["cleanup"]["clean"] or proof["cleanup"]["live_descendants"]:
        code = 70
    else:
        code = 0
    proof["exit_code"] = code
    proof["finished_monotonic_ns"] = time.monotonic_ns()
    proof["complete"] = True
    return code, proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", required=True, type=Path)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not command:
        parser.error("a foreground command is required after --")
    try:
        # Reserve a fresh file before launching anything; never replace old proof.
        with args.evidence.open("x") as output:
            code, proof = supervise(command)
            json.dump(proof, output, indent=2)
            output.write("\n")
            output.flush()
            os.fsync(output.fileno())
        return code
    except OSError as error:
        print(f"supervisor: {error}", file=sys.stderr)
        return 70


if __name__ == "__main__":
    sys.exit(main())
