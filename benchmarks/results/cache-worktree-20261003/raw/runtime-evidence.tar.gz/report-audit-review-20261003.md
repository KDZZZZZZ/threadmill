# Report audit review — 2026-10-03

Verdict: **Approve `audit-primary.py`; request two small changes to `audit-cache.py`.** The inspected saved outputs contain no numerical contradiction. The requested changes close holes in what the cache audit claims to validate; they do not identify a bad measured pytest row.

## Required changes

1. **Validate the row backend before invoking the terminal-state helper.** `audit-cache.py:54–58` checks group/repeat/mode but never `row['backend']`. The frozen `benchmarks/pi-runtime/bench.py:44–51` returns `{}` immediately for every backend that does not start with `threadmill-`. Thus a TM row with a missing/mistyped backend bypasses all runtime/VFS terminal counters while satisfying the current `terminal_state_errors == {}` comparison. Require `pi-worktree` for the Pi group and `threadmill-` plus the registered sandbox for each TM group. The existing execution backend check at line 80 does not fix the earlier dispatch bypass.

2. **Bind the supervisor evidence to this phase and the registered continuous-reaping method.** `audit-cache.py:112–114` checks success and cleanup but not the supervised command or `subreaper`/poll settings. A successful supervisor proof from a different phase would currently satisfy those checks. For this fixed launcher, verify `proof['command'][1:] == registration['argv']`, `subreaper is True`, and the registered 0.02-second polling policy; include the explicit empty `remaining`/`errors` cleanup fields. The inspected pytest proof already satisfies these facts: its command targets this pytest phase, `subreaper=true`, `poll_seconds=0.02`, and cleanup signals/live descendants/remaining/errors are all empty.

These guards can be checked with small, synthetic JSON mutations after the active diagnostic; no benchmark rerun is needed. I did not execute such tests or any audit during this review.

## Findings and scope

- Correctness: primary audit uses the frozen summarizer and terminal-state helper, verifies the helper SHA before import, checks every operation identity/class and exit, enforces physical endpoint/peak/delta arithmetic, and exits nonzero for missing rows as well as failed checks. The inspected output reports 144 completed rows, no missing rows and no failures. IPython external/576 remains two uninterrupted original completions in the capacity summary and three completed runs in the descriptive summary; both carry `formal_capacity_eligible=false` and the unresolved-interruption caveat.
- Correctness: cache audit recomputes the semantic oracle, operation inventory, count/throughput arithmetic, weighted-duration ratios, four wall medians, selected-command medians, tracing tax, service estimate and benchstat input text against the frozen helpers. The saved pytest output contains 40 rows, 600 expected reusable commands, 600 replays and zero unexpected replays. `shadow_audit=false` is appropriate because verification count/duration are zero; output self-digests and a semantic oracle do not establish fresh-execution output equality.
- Scope limitation (nonblocking): primary latency checks verify counts and nonnegative saved P50/P95 values; cache latency checks verify counts only. Neither recomputes these percentile values from operation durations. Describe these as checks of saved statistics, not an independent percentile recomputation. The frozen Pi implementation uses `samples[min(floor(n*p), n-1)]` at `benchmarks/pi-runtime/replay.mjs:169–171`.
- Readability: two standalone scripts, direct checks, no new abstraction or dependency. The cache script's fail-fast checks make its first failure actionable. Primary intentionally records multiple failures before returning nonzero.
- Architecture: reporting-only scripts. Imports reuse the committed frozen harness instead of duplicating its oracle/summary definitions; no runtime module or architecture dependency changed.
- Security: no shell or model invocation by the audit bodies. Imported project helpers are executable Python, so the supplied local project and registration remain trusted inputs; SHA consistency is not provenance authentication. Both scripts guard existing output files before writing. No credential content was read.
- Performance: no meaningful added hot path; these are offline audits. Primary retains a fixture's full row objects during summarization, so it should continue to run outside timed measurements. No optimization is required for this one-off report audit.

## Evidence inspected

Only small source/summary/registration/proof reads were performed; no script execution, test run, build, archive traversal, raw row traversal, fixture mutation or volume change.

| Artifact | SHA-256 |
| --- | --- |
| `audit-primary.py` | `fb74fc6081253093a2e7904bdb38029927904f6cc99e5699e59a115c4e079d7e` |
| `audit-cache.py` | `db6e8f269cd52b642f5ff299a5610668b26167b0fed4ddca7c4e6d512671880b` |
| `primary-audit.json` | `8d6542cd22fd2e762c6a9f0ac9457122403ad8a514e7e7383a5ee4e08a8d8745` |
| `pytest-audit.json` | `c5b65cca42573644a1a5bdb148140302c4afa519c7e488192d08b576764b6b29` |

Artifact directory: `/home/oops/repo/threadmill-cache-report/benchmarks/results/cache-worktree-20261003`.

Frozen references: `/home/oops/repo/threadmill-cache-bench/benchmarks/cache-runtime/bench.py` (`oracle_report`, `tracing_command`, `command_ns`, `benchmark_lines`, `compare`), `/home/oops/repo/threadmill-cache-bench/benchmarks/pi-runtime/bench.py` (`terminal_state_errors`, `summarize`), and its adjacent `replay.mjs` percentile reduction. The inspected registrations identify commit `b839b28747ae398f7badec9d2d0e51ae7e732c74`, cache helper SHA `4ac548af0bddf3ed5b7c6120f581d4f944b1d375cadc86f1386216a40c646d16`, primary helper SHA `8d620525a86a422bfa38283f869c7c3cf774b2a0e39767a0a65658e75ad7d4ac`, and Pi replay SHA `e26c1e5e1972501c023599766660d4e252614a9c9d23218df374e37f73c78f7e`.

## Resolution review

**Both required changes are resolved in source. Approve the final implementation, subject to the planned validation run.** Re-reviewed `audit-cache.py` SHA `62bd81381f1e8a0647ef5a0dfda75fd57cebd08b23ef340df51bfa86dfcc3a97` and the small parent control registration; no execution or raw-row traversal was performed.

- Exact `row['backend']` is checked before `terminal_state_errors`: Pi must be `pi-worktree`, and each TM group must be `threadmill-` plus the registered sandbox. This closes the dispatch bypass.
- Supervisor command equality is checked against both the control phase argv and the harness registration argv. The method requires `subreaper is True`, 0.02-second polling, 2-second TERM and 5-second KILL grace periods. The foreground return code and normal-exit cleanup trigger are checked, as are remaining descendants and cleanup errors. Existing success/clean/no-live/no-signal checks remain.
- Output records both the audit script SHA and parent control registration SHA, making the tightened checks and phase binding identifiable. Reproduction must preserve the phase directory name and its parent `registration.json`.

The previously inspected pytest control/proof fields agree with these comparisons. Root will still rerun the complete GREEN audit and incomplete/mismatched-proof negative checks in an idle interval; this source review does not claim those checks have run.
