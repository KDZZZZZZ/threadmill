# Go / strace cold-start diagnostic handoff

Static review only. No compiler, diagnostic workload, tests, container, host setting or formal runtime was run or changed by this sub-agent. All new files are in this directory. Root owns acceptance and execution.

## What is known

The new formal failure is `agent-0`, operation index `1`, the first cold `go test ./...`: 9,547,392,523 ns, exit 137, `PTRACE_LISTEN` EIO for PID 1645. The immutable row is `../formal-continuous-b839b28-20261003/cache-go/cache-on-traced-r1.json`, SHA256 `216bed39ea0eb38f0374e2cd9de131ad9e7e9c91b8fa8f466247ede510006af2`. The failed command's complete syscall trace and preceding wait events were removed by the frozen harness; its stopping signal and GETSIGINFO errno are unknown.

The earlier diagnostic completed 4 warmups and 128 warm vet invocations without observing this failure. That does not test many independent cold Go toolchains. Its `-d` output also cannot supply GETSIGINFO errno: strace 6.8's debug wait printer logs wait status/event/signal, while the GETSIGINFO result is reduced directly to a Boolean.

The local strace.c exactly matches official v6.8, SHA256 `21fe0b653612b9354ff783a9ca1643d39682d85fd38bf32a14b09cdea41febd1`. In `next_event`, an event-0 stop other than the syscall trap takes GETSIGINFO; **every failure** selects `TE_GROUP_STOP`. `dispatch_event` uses LISTEN for that category under SEIZE. A non-ESRCH restart error ends dispatch; with seccomp's EXITKILL option, tracer death can kill tracees. This explains a plausible route to exit 137, not the original trigger. [strace v6.8, strace.c](https://github.com/strace/strace/blob/v6.8/src/strace.c#L3769)

Only SIGSTOP/SIGTSTP/SIGTTIN/SIGTTOU are group-stopping signals; SEIZE group stops have `PTRACE_EVENT_STOP`. GETSIGINFO ESRCH is distinct from the EINVAL used to recognize a traditional group stop. [ptrace(2), group stops](https://man7.org/linux/man-pages/man2/ptrace.2.html)

Upstream Linux v7.0 returns EINVAL if GETSIGINFO has no `last_siginfo`, and ESRCH if the task cannot be inspected. LISTEN requires a seized task and a `last_siginfo` identifying `PTRACE_EVENT_STOP`; otherwise its default result is EIO. This is upstream reference source, **not a verified source match for Ubuntu 7.0.0-30-generic**. [Linux ptrace.c](https://github.com/torvalds/linux/blob/v7.0/kernel/ptrace.c#L636)

Go 1.24.2 uses SIGURG for asynchronous preemption. [Go signal_unix.go](https://github.com/golang/go/blob/go1.24.2/src/runtime/signal_unix.go#L43) Go issue #67383 reports SIGURG followed by LISTEN EIO, including amd64, and remains open as of its 2026-09-11 update. Its plain `strace -f` examples do not establish that this host's `-D`, seccomp or bwrap caused the failure. [Go issue #67383](https://github.com/golang/go/issues/67383)

No verified upstream fix was found. Pinned strace commit `bf822b2dd9ca0d51e992629f6f30687ed8abe696` still has the same broad GETSIGINFO-failure classification. An upgrade cannot be presented as a demonstrated remedy. [Pinned strace strace.c](https://github.com/strace/strace/blob/bf822b2dd9ca0d51e992629f6f30687ed8abe696/src/strace.c#L3942)

## Missing discriminator and decision rule

Capture **the same PID's wait status, stop signal, event bits, immediate GETSIGINFO return/errno, and subsequent GROUP_STOP dispatch**. Preserve all surrounding `-d` output and the raw syscall trace: strace batches wait events, so the last global wait line alone is insufficient.

| Observation | Supported conclusion |
| --- | --- |
| event 0, SIGURG (or another non-stopping signal), GETSIGINFO fails, GROUP_STOP then LISTEN/EIO | Invalid group-stop classification is demonstrated for this occurrence; errno narrows the state transition that still needs explanation. |
| GETSIGINFO ESRCH | A disappearing/unavailable ptrace state was misclassified. It does not prove an OOM kill or identify the cause of the transition. |
| GETSIGINFO EINVAL plus a non-stopping signal | `last_siginfo` was unavailable on the reference kernel path. A kernel/state race still needs investigation; EINVAL alone does not make SIGURG a valid group stop. |
| event 128 and a genuine stopping signal, then LISTEN/EIO | Investigate a different state/lifetime problem; do not assert the event-0 classifier caused it. |
| Four successful cold runs | Diagnostic inconclusive. No proof of repair or absence of the bug. |
| Budget timeout or incomplete supervisor proof | Diagnostic interrupted/invalid; not a reproduced LISTEN bug. |

Do not replace LISTEN with CONT/SYSCALL, suppress a signal, detach, disable preemption, remove tracing/seccomp, or retry a failed formal command on this evidence. Those changes can alter execution or omit dependencies.

## Concrete proposal

`instrumentation.patch` adds 16 lines to two sites. The GETSIGINFO call, Boolean classification and event handling remain the same; logging preserves its original errno. Successful siginfo fields are read only after a successful call. GROUP_STOP logging records the dispatch's own status. `strace-instrumented.c` is the exact patched source for review/build.

`build-proposal.json` gives two structured gcc argv lists copied from the existing official 6.8 build recipe: rebuild this one C translation unit and link the existing read-only `libstrace.a`. All compiler outputs go here; no install, make, or mutation of the earlier build tree is required. The source/static-library/header identity and compiler metadata must be recorded before execution. Build budget: 120 seconds. This static diagnostic binary differs from Ubuntu's dynamic host binary; it supplies causal observations, never performance data.

`proposal.json` fixes four sequential independent attempts, each with a fresh copied fixture, HOME and tmp. It applies **agent-0's exact initial pricing edit** (`subtotal * 90 / 100`, unlike agent-9's edit), then executes the exact failed `go test ./...` command once. Maximum 30 seconds per command, total 90 seconds including copy/setup; stop on the first error or timeout and preserve everything. Existing private environment is referenced only by path/hash and must never be published.

`run-cold.py` reuses the pinned earlier diagnostic's bounded capture helper. It never creates an inner subreaper. The validated continuous outer reaper must wrap it; inspect that reaper's proof even if the foreground exit is nonzero. Normal adopted exits are not leaks. Cleanup can add up to 12 seconds beyond the workload budget.

Root execution sequence:

1. Inspect the patch/runner and finish the ongoing formal phase and its audit.
2. In the sole hardware window, run the two build argv lists with bounded timeouts, save logs, capture hashes of the actual compiler inputs from `strace-instrumented.d`, and write `build-evidence.json`.
3. Run a separate bounded trivial-command smoke probe under the continuous reaper; preserve its output/proof separately. Perform Python syntax/identity checks. Neither has been run by this sub-agent.
4. Copy `proposal.json` to a **new** `registration.json`; set `status` to `sealed_by_root`, fill the instrumented binary hash and build-evidence hash. Add any newly recorded build pins. Freeze and record the resulting registration hash.
5. Launch `supervise.py --evidence <this-directory>/supervisor.json -- python3 -B <this-directory>/run-cold.py --plan <this-directory>/registration.json --registration-sha256 <hash> --execute`. Root records launcher/process identity and uses its normal detached supervised launch. Never restart this directory.
6. Inspect `run/run-status.json`, every complete stderr/stdout log, raw traces referenced in records, and `supervisor.json`. Report findings before considering any runtime change.

The constructor of the proposal and input-path existence checks were the only Python operations used here. No claim is made that the C patch compiles or that the new runner has passed an execution test. The reused capture helper and outer reaper were previously validated by root.

## Source and artifact record

`sources.json` records fetched primary-source URLs and SHA256s. The first raw Linux download failed SSL; the second succeeded. GitHub issue/API snapshots are preserved separately. The report distinguishes these upstream facts from this host's unknown failure event.

Proposal SHA256: `bdd36f0b60db5a6bde37a2a8b0e6b4d9c38a438f5adb4c1753deb4535e154428`.

Runner SHA256: `a33a4b0deb5290d008bedfcec76b4a0852171d46ddd7ff5f0f90f7436931d293`.
