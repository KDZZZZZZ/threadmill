#!/usr/bin/python3
"""Bounded diagnostic proposal. Only execute under the registered outer reaper."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def invocation(plan, label):
    work = Path(plan["work_root"]) / label
    argv = ["/usr/bin/bwrap", "--unshare-user", "--unshare-pid", "--die-with-parent",
            "--tmpfs", "/", "--dir", "/workspace", "--bind", str(work / "repo"), "/workspace",
            "--bind", str(work / "home"), "/home/threadmill", "--bind", str(work / "tmp"), "/tmp"]
    for path in plan["bwrap_readonly_paths"]:
        argv += ["--ro-bind-try", path, path]
    argv += ["--ro-bind", plan["instrumented_tracer"], "/usr/bin/strace",
             "--dev", "/dev", "--proc", "/proc", "--chdir", "/workspace", "--",
             "/usr/bin/strace", "-d", *plan["strace_flags"], "-o", "/tmp/.tmtrace-" + label,
             "--", "bash", "-c", plan["command"]]
    return argv


def validate(plan_path, registered_sha):
    require(sha(plan_path) == registered_sha, "registration SHA256 differs")
    plan = json.loads(plan_path.read_text())
    require(plan["status"] == "sealed_by_root", "proposal is not a sealed registration")
    require(plan["formal"] is False, "diagnostic cannot be formal data")
    require(plan["total_seconds"] == 90 and plan["cold_attempt_limit"] == 4,
            "fixed diagnostic budget changed")
    require(plan["command_timeout_seconds"] == 30, "per-command bound changed")
    require(os.getuid() == plan["uid"] == os.geteuid(), "run as original uid")
    for path, expected in plan["files_sha256"].items():
        require(expected and sha(path) == expected, "input identity differs: " + path)
    require(sha(plan["instrumented_tracer"]) == plan["instrumented_tracer_sha256"],
            "instrumented tracer identity differs")
    private = Path(plan["private_environment_path"])
    require(private.stat().st_mode & 0o777 == 0o600, "environment must remain private")
    require(sha(private) == plan["private_environment_sha256"], "environment differs")
    environment = json.loads(private.read_text())
    require(not any(k in environment for k in ("GODEBUG", "GOMAXPROCS", "GOCACHE", "LD_PRELOAD")),
            "diagnostic must not change Go scheduling/cache or preload")
    require(environment["HOME"] == "/home/threadmill" and environment["TMPDIR"] == "/tmp",
            "sandbox HOME/TMPDIR differs")
    fixture = plan["fixture"]
    git = ["/usr/bin/git", "-c", "safe.directory=" + fixture, "-C", fixture]
    git_env = {"PATH": "/usr/bin:/bin", "GIT_OPTIONAL_LOCKS": "0"}
    head = subprocess.check_output(git + ["rev-parse", "HEAD"], env=git_env, timeout=5).decode().strip()
    dirty = subprocess.check_output(git + ["status", "--porcelain"], env=git_env, timeout=5).strip()
    require(head == plan["fixture_commit"] and not dirty, "fixture identity/cleanliness differs")
    require(not Path(plan["work_root"]).exists() and not (BASE / "run").exists(),
            "diagnostic workspace or output already exists; never restart")
    for item in plan["invocations"]:
        require(invocation(plan, item["label"]) == item["argv"], "registered argv differs")
    require([x["label"] for x in plan["invocations"]] == [f"cold-{i:02d}" for i in range(1, 5)],
            "registered invocation sequence differs")
    return plan, environment


def execute(plan, environment):
    output = BASE / "run"
    output.mkdir(mode=0o700)
    work_root = Path(plan["work_root"])
    work_root.mkdir(mode=0o700)
    spec = importlib.util.spec_from_file_location("pinned_diagnostic_helper", plan["helper"])
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    helper.BASE = output
    status = {"started_utc": now(), "formal": False, "records": [], "outcome": "incomplete",
              "subreaper_owner": "registered continuous outer supervisor only",
              "registered_max_seconds": 90, "max_cold_attempts": 4}
    helper.emit(output / "run-status.json", status)
    deadline = time.monotonic() + 90

    def interrupted(signum, _frame):
        raise InterruptedError("received signal " + str(signum))

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        for item in plan["invocations"]:
            if time.monotonic() >= deadline:
                status["outcome"] = "budget_exhausted_without_observed_failure"
                break
            label = item["label"]
            work = work_root / label
            work.mkdir(mode=0o700)
            helper.capture(["/usr/bin/cp", "-a", "--reflink=always", plan["fixture"], str(work / "repo")],
                           {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"}, label + "-copy", 10,
                           deadline, status["records"])
            for name in ("home", "tmp"):
                (work / name).mkdir(mode=0o700)
            write = plan["initial_write"]
            (work / "repo" / write["path"]).write_text(write["content"])
            trace = work / "tmp" / (".tmtrace-" + label)
            os.close(os.open(trace, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600))
            print(json.dumps({"starting": label, "formal": False, "fresh_home": True}), flush=True)
            try:
                helper.capture(item["argv"], environment, label, 30, deadline, status["records"])
            finally:
                status["records"][-1]["trace"] = str(trace)
                status["records"][-1]["trace_sha256"] = sha(trace)
        else:
            status["outcome"] = "invocation_limit_reached_without_observed_failure"
    except BaseException as error:
        status["outcome"] = "stopped_on_first_failure"
        status["failure"] = repr(error)
        raise
    finally:
        status["ended_utc"] = now()
        temporary = output / "run-status.tmp"
        temporary.write_text(json.dumps(status, indent=2) + "\n")
        temporary.replace(output / "run-status.json")
        print(json.dumps({"outcome": status["outcome"], "records": len(status["records"])}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--registration-sha256", required=True)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    plan, environment = validate(args.plan, args.registration_sha256)
    if args.execute:
        execute(plan, environment)
    else:
        print(json.dumps({"identity": "passed", "workload_executed": False}))
