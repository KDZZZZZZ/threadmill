import datetime, hashlib, json, os, shlex, subprocess, time
from pathlib import Path
p=Path(__file__).resolve().parent
plan=json.loads((p/'build-proposal.json').read_text())
sha=lambda f: hashlib.sha256(Path(f).read_bytes()).hexdigest()
assert not (p/'strace-diagnostic').exists() and not (p/'build-evidence.json').exists()
started=time.monotonic(); evidence={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'formal':False,'budget_seconds':120,'commands':[],'input_sha256':{f:sha(f) for f in plan['input_paths_to_pin']},'compiler':subprocess.check_output(['/usr/bin/gcc','--version'],text=True),'compiler_sha256':sha('/usr/bin/gcc'),'build_proposal_sha256':sha(p/'build-proposal.json')}
try:
 for i,argv in enumerate(plan['commands'],1):
  with (p/f'build-{i}.log').open('x') as log:
   result=subprocess.run(argv,cwd=plan['cwd'],stdout=log,stderr=subprocess.STDOUT,timeout=max(1,120-(time.monotonic()-started)))
  evidence['commands'].append({'argv':argv,'exit_code':result.returncode,'log_sha256':sha(p/f'build-{i}.log')})
  if result.returncode: raise RuntimeError(f'build command{i} failed')
 deps=(p/'strace-instrumented.d').read_text().replace('\\\n',' ')
 for value in shlex.split(deps.partition(':')[2]):
  path=Path(value)
  if not path.is_absolute():path=p/path
  evidence['input_sha256'][str(path)]=sha(path)
 for f in plan['input_paths_to_pin']:
  assert sha(f)==evidence['input_sha256'][f], f
 evidence['binary_sha256']=sha(p/'strace-diagnostic')
 evidence['binary_version']=subprocess.check_output([str(p/'strace-diagnostic'),'-V'],text=True,timeout=5)
 evidence['success']=True
except BaseException as error:
 evidence['success']=False; evidence['error']=repr(error)
 raise
finally:
 evidence['ended_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();evidence['elapsed_seconds']=time.monotonic()-started
 (p/'build-evidence.json').write_text(json.dumps(evidence,indent=2)+'\n')
