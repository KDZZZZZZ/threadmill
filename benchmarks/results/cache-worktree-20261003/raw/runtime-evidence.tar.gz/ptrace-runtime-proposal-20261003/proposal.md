# One frozen-runtime ptrace diagnostic

Prepared by the sub-agent for root review. **Not compiled, installed, syntax-checked, tested or executed.** Only this new proposal directory was written. Root must wait for an exclusive hardware window.

This is a reasonable next discriminator: the four direct cold Go probes did not exercise `tmload`, its cache lookup/store paths, or Scheduler process tracking. Run the unchanged frozen `b839b28747ae398f7badec9d2d0e51ae7e732c74` tmload binary against the exact original 16-agent/96-command Go trace once, with sparse diagnostic logging in strace. No second attempt is proposed.

## Smallest integration

Install a real diagnostic ELF named `strace` into the **new** directory `/usr/local/share/threadmill-bench/ptrace-runtime-b839-20261003-v1/`. The directory must not already exist; installation aborts on an existing path. No existing strace or other tool is replaced. Only this tmload invocation gets this directory prepended to its original PATH. It contains no other executable names.

This fits the frozen runtime directly: `tracerPath` calls `exec.LookPath("strace")`, resolves symlinks, and probes the resolved absolute path. The bwrap gate accepts a real path under `/usr/` or `/bin/`; `/usr` is already a read-only bind mount. `THREADMILL_STRACE_BINARY` only affects the Python harness's version record and does **not** select the runtime tracer. A symlink into `/home` would fail the resolved-path gate. [tracer selection and gate](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/internal/exec/trace.go#L195), [existing bwrap read-only paths](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/internal/exec/bwrap.go#L15), [harness version record](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/benchmarks/cache-runtime/bench.py#L173).

There is no added mount namespace, UID change, Go scheduling override, cache-policy change or tracing-policy change. The original runtime already creates its usual bwrap namespaces. PATH is an intentional diagnostic environment change and participates in the cache environment hash; all cache state starts fresh. This attempt cannot be used as a performance observation. [cache environment hash](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/internal/exec/trace.go#L335).

## Logging and evidence boundary

The patch starts from official strace 6.8, source SHA256 `21fe0b653612b9354ff783a9ca1643d39682d85fd38bf32a14b09cdea41febd1`. It logs only:

- Failed GETSIGINFO: namespace PID, exact wait status, stop signal, event bits, SEIZE mode, immediate return and errno, and trace output path.
- GROUP_STOP dispatch: that dispatch's own PID/status/signal/event/SEIZE mode and trace output path.

Both sites preserve errno. No ptrace call is added, no classification or restart operator changes, and `-d` is absent. [Official 6.8 event classification](https://github.com/strace/strace/blob/v6.8/src/strace.c#L3769).

The complete operation output is saved by frozen tmload into `operations[].output`, subject to its original 256 KiB head/tail cap. Sparse lines can identify the failed classification without a new collector. [operation output storage](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/cmd/tmload/replay.go#L236), [default cap](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/internal/exec/scheduler.go#L27).

**Raw syscall traces will not be retained.** `storeTrace` defers `trace.discard()` after each execution, and `Reap` deletes the environment's runtime directory. Skipping the outer harness's `rmtree` does not preserve those files. A reliable raw-file collector would require earlier descriptor retention or additional instrumentation/IPC; that complexity is unnecessary for the current errno/status question. No fd collector or file watcher is proposed. [per-command discard](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/internal/exec/cached.go#L56), [discard implementation](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/internal/exec/trace.go#L323).

Frozen tmload continues subsequent preregistered operations after a command error, then writes JSON only when the full trace returns. This behavior remains intact; no adaptive retry is introduced. Therefore a watchdog timeout before report creation may leave **no operation diagnostic output**, and must be classified as an inconclusive interruption. [replay loop and report completion](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/cmd/tmload/replay.go#L221), [final JSON write](https://github.com/KDZZZZZZ/threadmill/blob/b839b28747ae398f7badec9d2d0e51ae7e732c74/cmd/tmload/trace_cli.go#L75).

## Execution contract

`proposal.json` contains the full frozen argv and pinned inputs. The input trace remains SHA256 `baf4c6a47a0d28d72dd0ff199131c2bbf18139d246df06850f3a2e7135e04ff2`; fixture commit remains `ebdc501eff1b19538943448dd9318bf69e3010a9`; tmload remains SHA256 `05ea03a95b30be48564624c1d49f267b5ff87bf791bdb8c91b9a24d17937c4bf`.

One fresh copied fixture, empty runtime/cache and TMPDIR; 16 serial agents; 96 original bash operations; bwrap; one slot; cache/tracing enabled; verify sample rate 0; retain checkpoints. Maximum setup 10 seconds plus **270 seconds for the single tmload invocation**, then up to 12 seconds for the existing capture/supervisor cleanup. No second run. No data enters the old formal statistics.

`run-runtime.py` reuses the previously pinned bounded capture helper and requires the continuous outer reaper as the sole subreaper. It records actual PATH resolution and installed tracer SHA before/after, the existing bwrap read-only path list, raw-trace absence, process exit and final result SHA. It extracts diagnostic/failed operations from the final JSON for review. Root must still inspect the supervisor's complete cleanup proof, including on a nonzero foreground exit.

`build-proposal.json` gives the two structured gcc commands that rebuild only this logging C translation unit and link the already verified official 6.8 static library. Its install commands use exclusive directory creation, followed by installation into that newly created directory. Record compiler inputs/build log/library SHA and built-versus-installed binary equality in `build-evidence.json`. This static binary differs from the Ubuntu dynamic tracer and remains diagnostic-only.

Root supplies the original formal outer environment as a private mode-0600 JSON file; this runner changes only PATH and TMPDIR. Do not use the earlier direct-probe environment as the outer environment: its HOME already names the sandbox HOME. Do not publish the private file. Any unknown equality of forwarded values against the original measurement must remain documented.

After review/build/installation and syntax/identity checks, root copies `proposal.json` to a new `registration.json`, fills the three missing hashes (binary, environment, build evidence), and sets `status` to `sealed_by_root`. Freeze that registration and record its SHA. Run:

```text
python3 supervise.py --evidence <proposal-directory>/supervisor.json --
  python3 -B <proposal-directory>/run-runtime.py
  --plan <proposal-directory>/registration.json
  --registration-sha256 <sealed-hash> --execute
```

Root uses its existing detached launch with identity recording and no resource-policy changes. The runner refuses an existing work or result directory, preventing automatic restarts.

## Interpretation

A same-operation event-0/non-stopping signal with GETSIGINFO failure followed by GROUP_STOP and LISTEN/EIO would demonstrate incorrect group-stop classification for that occurrence. ESRCH versus EINVAL narrows the unavailable-state question; it does not establish what caused that state. A genuine event-128 stopping signal would require a different investigation. Missing/truncated logs, startup-gate failure, timeout or incomplete cleanup proof are inconclusive. A completed successful replay also remains inconclusive. No speculative tracer recovery patch follows automatically. [ptrace group-stop rules](https://man7.org/linux/man-pages/man2/ptrace.2.html).

## Frozen draft identities

- `proposal.json`: `fe0e475c3a7f8ccd330947a4070a728427878754951efbcd8816cbd1d03ac405`
- `run-runtime.py`: `3d7a0e2f46a39b60c6a425cf0649de0ac4b5b9c7a2b2113f2aa47558714d3cd1`
- `instrumentation.patch`: `3668b815c85d0f4e81bc9430a66219d9d4e806eeb70fb70a782d88ebc409beb4`

The sub-agent performed source reading and generated the draft only. There has been no build, install, syntax check, workload, container or large-log scan.
