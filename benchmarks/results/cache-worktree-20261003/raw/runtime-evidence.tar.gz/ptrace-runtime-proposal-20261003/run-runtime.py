#!/usr/bin/python3
"""One diagnostic replay of the frozen runtime; never formal benchmark data."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import signal
import sys
import time

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
HELPER = Path('/home/oops/evals/threadmill-cache-bench/ptrace-listen-diag-20261003/diagnose.py')
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != '38117f7658f17f3b70e866fb12c4b0cfeb7aaadd6b1ac07e3632f9ec6a107d17':
    raise RuntimeError('capture helper identity differs')
spec = importlib.util.spec_from_file_location('pinned_capture_helper', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)


def validate(path, expected):
    helper.require(helper.sha(path) == expected, 'registration SHA256 differs')
    plan = json.loads(path.read_text())
    helper.require(plan['status'] == 'sealed_by_root' and plan['formal'] is False, 'unsealed proposal')
    helper.require(plan['attempts'] == 1 and plan['command_timeout_seconds'] == 270, 'fixed bound differs')
    helper.require(os.getuid() == os.geteuid() == plan['uid'] == 1000, 'original uid required')
    for name, digest in plan['files_sha256'].items():
        helper.require(digest and helper.sha(name) == digest, 'input identity differs: ' + name)
    private = Path(plan['private_environment_path'])
    helper.require(private.stat().st_mode & 0o777 == 0o600, 'environment must remain private')
    helper.require(helper.sha(private) == plan['private_environment_sha256'], 'environment differs')
    environment = json.loads(private.read_text())
    helper.require(environment['PATH'] == plan['original_path'], 'original PATH differs')
    helper.require(environment.get('HOME') == '/home/oops', 'outer HOME differs')
    helper.require(not any(k in environment for k in ('GODEBUG', 'GOMAXPROCS', 'GOCACHE', 'LD_PRELOAD')),
                   'unexpected scheduling/cache/preload override')
    directory = Path(plan['tracer_directory'])
    tracer = directory / 'strace'
    helper.require(directory.is_dir() and not directory.is_symlink(), 'diagnostic directory is not real')
    helper.require({p.name for p in directory.iterdir()} == {'strace'}, 'PATH directory must contain only strace')
    helper.require(not tracer.is_symlink() and tracer.is_file(), 'diagnostic tracer must be an ELF, not a symlink')
    helper.require(tracer.read_bytes()[:4] == b'\x7fELF', 'diagnostic tracer is not ELF')
    helper.require(helper.sha(tracer) == plan['installed_tracer_sha256'], 'installed tracer differs')
    environment['PATH'] = str(directory) + ':' + plan['original_path']
    work = Path(plan['work_root'])
    environment['TMPDIR'] = str(work / 'tmp')
    resolved = shutil.which('strace', path=environment['PATH'])
    helper.require(resolved and Path(resolved).resolve() == tracer, 'PATH resolved a different tracer')
    helper.require(not work.exists() and not (BASE / 'run').exists(), 'attempt already exists; never restart')
    expected_argv = [plan['tmload'], '-trace-in', plan['trace'], '-repo', str(work / 'repo'),
                     '-workdir', str(work / 'runtime'), '-sandbox', 'bwrap', '-slots', '1',
                     '-cache=true', '-dependency-tracing=true', '-cache-verify-sample-rate', '0',
                     '-retain=true', '-json-out', str(BASE / 'run' / 'result.json')]
    helper.require(plan['argv'] == expected_argv, 'frozen runtime invocation differs')
    return plan, environment, tracer


def execute(plan, environment, tracer):
    output = BASE / 'run'
    output.mkdir(mode=0o700)
    work = Path(plan['work_root'])
    work.mkdir(mode=0o700)
    (work / 'tmp').mkdir(mode=0o700)
    helper.BASE = output
    status = {'started_utc': helper.now(), 'formal': False, 'outcome': 'incomplete', 'records': [],
              'attempts': 1, 'command_timeout_seconds': 270, 'subreaper_owner': 'continuous outer supervisor only',
              'actual_path_tracer': str(tracer), 'tracer_sha256_before': helper.sha(tracer),
              'bwrap_readonly_paths': plan['bwrap_readonly_paths'], 'raw_syscall_traces_retained': False,
              'reason_no_raw_trace': 'Frozen storeTrace discards each trace and Reap removes per-environment runtime dirs.',
              'trace_error_policy': 'Frozen tmload continues the preregistered trace after operation errors; no retry is added.'}
    helper.emit(output / 'run-status.json', status)
    # At most ten seconds of setup plus 270 seconds for this one invocation.
    deadline = time.monotonic() + 280

    def interrupted(signum, _frame):
        raise InterruptedError('received signal ' + str(signum))

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        helper.capture(['/usr/bin/cp', '-a', '--reflink=always', plan['fixture'], str(work / 'repo')],
                       {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8'}, 'copy-fixture', 10, deadline, status['records'])
        helper.capture(plan['argv'], environment, 'tmload', 270, deadline, status['records'])
        status['outcome'] = 'completed_without_process_failure'
    except BaseException as error:
        status['outcome'] = 'failed_or_interrupted'
        status['failure'] = repr(error)
        raise
    finally:
        result = output / 'result.json'
        status['result_present'] = result.exists()
        if result.exists():
            status['result_sha256'] = helper.sha(result)
            try:
                report = json.loads(result.read_text())
                status['errors'] = report.get('errors')
                status['bash_operations'] = sum(row['op'] == 'bash' for row in report.get('operations', []))
                status['diagnostic_or_failed_operations'] = [row for row in report.get('operations', [])
                    if 'tm_diag_' in row.get('output', '') or row.get('exit_code', 0) or row.get('error')]
            except (ValueError, KeyError) as error:
                status['result_read_error'] = repr(error)
        status['tracer_sha256_after'] = helper.sha(tracer)
        status['ended_utc'] = helper.now()
        temporary = output / 'run-status.tmp'
        temporary.write_text(json.dumps(status, indent=2) + '\n')
        temporary.replace(output / 'run-status.json')
        print(json.dumps({'outcome': status['outcome'], 'result_present': status['result_present']}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--registration-sha256', required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    plan, environment, tracer = validate(args.plan, args.registration_sha256)
    if args.execute:
        execute(plan, environment, tracer)
    else:
        print(json.dumps({'identity': 'passed', 'tracer': str(tracer), 'workload_executed': False}))
