"""Build only the reviewed strace logging translation unit in a new directory."""
import datetime
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import time

if not __debug__:
    raise SystemExit('Run without Python optimization; build identity assertions are required')

root = Path(__file__).resolve().parent
plan = json.loads((root / 'build-proposal.json').read_text())
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert not (root / 'strace-diagnostic').exists() and not (root / 'build-evidence.json').exists()
assert sha(plan['input_paths_to_pin'][0]) == plan['source_sha256']
prior_path = root.parent / 'ptrace-cold-review-20261003/build-evidence.json'
prior = json.loads(prior_path.read_text())
assert prior['success'] and sha('/usr/bin/gcc') == prior['compiler_sha256']
for path in plan['input_paths_to_pin']:
    if Path(path).parent != root:
        assert sha(path) == prior['input_sha256'][path], path
started = time.monotonic()
evidence = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'formal': False,
            'budget_seconds': plan['build_budget_seconds'], 'commands': [],
            'input_sha256': {path: sha(path) for path in plan['input_paths_to_pin']},
            'compiler': subprocess.check_output(['/usr/bin/gcc', '--version'], text=True),
            'compiler_sha256': sha('/usr/bin/gcc'), 'build_proposal_sha256': sha(root / 'build-proposal.json'),
            'prior_verified_build_evidence_sha256': sha(prior_path)}
try:
    for index, argv in enumerate(plan['commands'], 1):
        with (root / f'build-{index}.log').open('x') as log:
            result = subprocess.run(argv, cwd=plan['cwd'], stdout=log, stderr=subprocess.STDOUT,
                                    timeout=max(1, plan['build_budget_seconds'] - (time.monotonic() - started)))
        evidence['commands'].append({'argv': argv, 'exit_code': result.returncode,
                                     'log_sha256': sha(root / f'build-{index}.log')})
        if result.returncode:
            raise RuntimeError(f'build command {index} failed')
    dependencies = (root / 'strace-instrumented.d').read_text().replace('\\\n', ' ')
    for value in shlex.split(dependencies.partition(':')[2]):
        path = Path(value)
        if not path.is_absolute():
            path = root / path
        evidence['input_sha256'][str(path)] = sha(path)
        if path.parent != root:
            assert evidence['input_sha256'][str(path)] == prior['input_sha256'][str(path)], str(path)
    for path in plan['input_paths_to_pin']:
        assert sha(path) == evidence['input_sha256'][path], path
    evidence['binary_sha256'] = sha(root / 'strace-diagnostic')
    evidence['binary_version'] = subprocess.check_output([str(root / 'strace-diagnostic'), '-V'], text=True, timeout=5)
    evidence['success'] = True
except BaseException as error:
    evidence['success'] = False
    evidence['error'] = repr(error)
    raise
finally:
    evidence['ended_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    evidence['elapsed_seconds'] = time.monotonic() - started
    with (root / 'build-evidence.json').open('x') as stream:
        json.dump(evidence, stream, indent=2)
        stream.write('\n')
