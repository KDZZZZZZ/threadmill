# Harbor lang03 专用 AppArmor 配置提案

这是供人类批准的三个具体文件。2026-10-03T13:40:48Z 已通过 apparmor_parser --skip-kernel-load --skip-cache --jobs 1 的离线语法检查（退出 0）；profile 尚未加载，也未执行依赖它的诊断容器。用途是对原始 lang03 任务用户做一次有时间上限的 namespace 与 Threadmill 准入诊断。没有修改适配器、任务、评分器、宿主策略或 Docker 状态，也没有模型调用。

`threadmill-harbor-lang03-userns.apparmor` 定义一个无路径 attachment 的命名 profile；Docker 只有显式选择它时才使用。它保留本次诊断原有的 unconfined 行为，并允许 user namespace，以解除此前 `unconfined → unprivileged_userns` 后发生的 `setpcap` 和 `uid_map` 拒绝。这是**容器范围的 user namespace 限制放宽**，涵盖继承此 profile 的进程，范围宽于仅允许 bwrap 初始化。它不全局关闭 AppArmor，不修改两个 user namespace sysctl，不给宿主 `/usr/bin/bwrap` 自动附加规则，不改变任务 USER，也不添加 privileged、setuid 或 file capabilities。完整准入尚未证明，不能把这个候选称为生产级最小权限策略。

本次建议批准的应用对象仅为独立 daemon 中的一个临时容器 `threadmill-harbor-lang03-userns-diagnostic` 及其进程，包括既有安装流程的 root 文件准备和随后 UID 2000 的运行时探针。它不授权给其他任务容器、网络 sidecar 或 separate verifier 选择该 profile；也不授权以 root 身份运行 agent。

`docker-compose.yaml` 是当前 workspace overlay 的普通 YAML 替代文件。唯一策略差异是 `apparmor=unconfined` 改为候选名称；原有 `SYS_ADMIN` cap_add 和 VFS 命名卷保留。它不设置用户、CPU、内存、存储、超时、网络或 grader。

必须让该文件**替代**原 workspace overlay，而不是追加到其后。普通 Compose 列表合并会保留两个 AppArmor 条目；Compose 的 `!override` 又不能直接穿过 Harbor 0.22.0 出站网络设置中的 `yaml.safe_load`。当前 Threadmill `bench` 和 doctor 仍固定选择旧策略，本提案没有改动这些入口，也不是可直接启动正式 A/B 的配置包。

**原任务资源与身份的直接来源**

本地源文件是 `/home/oops/repo/threadmill/benchmarks/.work/swe-refactor-bench/source/tasks/lang03-sqlparse-python-to-go/task.toml`，上游提交 `1270471ccb5e6f254627784658d4e29acb90b953`。这两个被检查文件的 Git status 均无修改。

| 配置段 | 原值 |
| --- | --- |
| `agent` | `user="agent"`，`timeout_sec=54000.0`，`network_mode="no-network"` |
| `environment` | `cpus=4`，`memory_mb=8192`，`storage_mb=20480`，`gpus=0` |
| `environment` 其他约束 | `build_timeout_sec=3600.0`，`network_mode="no-network"`，`workdir="/workspace/repo"` |
| `verifier` | `environment_mode="separate"`，`user="root"`，`timeout_sec=75600.0` |
| `verifier.environment` | `cpus=4`，`memory_mb=8192`，`storage_mb=20480`，`gpus=0`，`build_timeout_sec=7200.0`，`network_mode="no-network"` |

任务 Dockerfile 的 `groupadd --gid 2000`、`useradd --uid 2000 --gid 2000` 和最后的 `USER agent` 与已保留实际运行身份一致。任务的隐藏评分环境是 separate；本诊断不启动它。此处 300 秒的诊断上限不更改正式任务的 54000 秒或 verifier 的 75600 秒预算。

**已核对 separate verifier 的继承边界。** 已安装 Harbor 0.22.0 的 `harbor/trial/trial.py:753` 在创建 separate verifier 时使用 `model_copy(update={"extra_docker_compose": []})`，然后把 verifier 原始 `env_config` 传给工厂。因此通过普通 Harbor `--extra-docker-compose` 传入的本文件不会自动传给 separate verifier；它的 root 身份、独立环境、资源、网络、超时和 grader 保持原任务设置。这个静态结论限于已检查的 Harbor 0.22.0 路径，不覆盖自定义 Pier subclass 或未来代码。`trial.py` SHA256 为 `1c3621714a794697bc9d30ed61107b344601f3c1c51d617e353856ca8044c3ba`，安装根为 `/home/oops/.local/share/uv/tools/harbor/lib/python3.12/site-packages`。[Harbor 对 separate verifier 的实现](https://github.com/harbor-framework/harbor/blob/v0.22.0/src/harbor/trial/trial.py)

- `task.toml` SHA256：`4a8a3f49da13c5a1671d098e04ef12d0dbc38d22a3861e4fd7a77427d973af45`。
- `environment/Dockerfile` SHA256：`a6631c6826ded813ef3a56689a1a6546d67f0d4308cd0da0c5f1404b84702e51`。
- [固定提交的任务配置](https://github.com/Einsia/SWE-Refactor-Bench/blob/1270471ccb5e6f254627784658d4e29acb90b953/tasks/lang03-sqlparse-python-to-go/task.toml)和[任务 Dockerfile](https://github.com/Einsia/SWE-Refactor-Bench/blob/1270471ccb5e6f254627784658d4e29acb90b953/tasks/lang03-sqlparse-python-to-go/environment/Dockerfile)。

现有 `../harbor-admission-20261003/doctor-bwrap-lang03-diagnostic-commands.json` 保留的 `docker create` argv 没有 `--cpus`、`--memory` 或存储限额；相应 doctor 报告 `cpu.max=max 100000`、`memory.max=max`。所以旧失败只能证明真实 USER 下的能力阻断，不能证明原任务预算已经应用。未来必须记录实际 CPU、内存及存储处理方式；仅配置 `storage_mb=20480` 不等于本地 Docker 已强制执行该上限。

**可用存储容量仍需补足。** 同一保留报告的 `df` 显示 Docker 使用 Btrfs `/dev/loop32`，总量为 12,582,912 KiB，即 12 GiB，低于任务声明的 `storage_mb=20480`。后续官方文档核对纠正了最初把 quota 列为必需门禁的表述：storage_mb 是容量请求，storage 没有 enforcement policy，Docker 也不在 storage sizing provider 列表中。需补足可用容量并披露 Docker 不强制这个存储上限，不新增自制配额要求。参见 [Harbor 资源语义](https://docs.harborframework.com/core-concepts/tasks/resources)。本 profile 提案本身不执行扩容；namespace 诊断不代表全部正式实验前提已满足。

**批准后才能执行的装载与撤销**

先确认没有同名已加载 profile；若已存在则停止，不能替换未知策略。以下命令均未执行。装载需要管理员权限；只在正式性能测量空闲且明确批准后进行。

```sh
sudo apparmor_parser -a -W /home/oops/evals/threadmill-cache-bench/harbor-scoped-profile-proposal-20261003/threadmill-harbor-lang03-userns.apparmor
```

只允许此次诊断容器显式选择 `apparmor=threadmill-harbor-lang03-userns`。不修改 Docker daemon 默认策略，不重启 daemon，不把文件安装到开机加载目录。诊断结束或任何步骤失败，都应先删除本次容器及其命名卷，然后卸载：

```sh
sudo apparmor_parser -R /home/oops/evals/threadmill-cache-bench/harbor-scoped-profile-proposal-20261003/threadmill-harbor-lang03-userns.apparmor
```

撤销后检查该名称不再加载，宿主 `kernel.unprivileged_userns_clone` 和 `kernel.apparmor_restrict_unprivileged_userns` 与诊断前一致。不修改或卸载本机其他 profile。

**一次有界诊断的验收范围**

总诊断上限为 300 秒，结束后的清理最多 30 秒；最小 bwrap 命令最多 15 秒，完整 `-exec-doctor` 最多 120 秒。第一次失败立即停止，不自动重试、不追加权限、不进入 pilot 或模型调用。

1. 固定原镜像 `sha256:7c2ff0c6f15dde754fcd6958193a97d4f5d6336cb6000d6ccff85fb65facf458` 及上面的任务身份、网络约束。仅创建指定诊断容器，使用既有独立 daemon `unix:///home/oops/evals/threadmill-cache-bench/docker-run/docker.sock`，应用原值 4 CPU、8192 MB 内存，并在实际 cgroup 中确认。本轮只验证 namespace 能力，原任务的 20480 MB 存储要求及当前 12 GiB 容量差距原样保留；不运行正式任务、不把这种能力诊断记作资源预算等价的准入成功。
2. 沿既有安装流程准备普通 root:root/0755 bwrap、静态 strace 和可写目录。安装阶段的 root 文件准备应单独记录；随后所有 runtime 探针都使用镜像原始 USER `agent`，不得给探针增加 `--user root`。记录工具哈希与实际解析路径。
3. 记录任务进程的 `id`、AppArmor 标签、`NoNewPrivs`、`Seccomp` 和全部 capability 字段。旧证据的 Inh/Prm/Eff/Amb 为零，**CapBnd 为 `00000000a82425fb`**；不能把它描述为所有集合均为零。确认候选标签经过 shell → Threadmill → bwrap 执行链时的实际行为。
4. 以原 USER 重跑原最小 bwrap 命令：`/usr/bin/bwrap --unshare-user --unshare-pid --ro-bind / / --proc /proc --dev /dev -- /bin/true`。返回 0 后，再在同一约束下运行完整 Threadmill `-exec-doctor`。后者必须退出 0、后端为 bwrap、依赖追踪可用且启用；保留 stdout JSON、stderr 和同一时间窗的内核审计。
5. 确认最终载荷身份、工作区写入和预定只读映射；保留 cgroup 与清理结果。新出现的 seccomp、mount、ptrace 或文件拒绝都视为此次诊断未通过。AppArmor 放行不意味着其他权限自动具备。随后销毁本次资源并卸载候选。

这次批准的直接结果只是验证选定容器的能力前提；是否正式采用该策略仍需纳入预注册记录。Responses 兼容模型配置是独立前提，本文没有选择模型或修改协议。

**官方依据及相关只读审查**

- [Ubuntu 24.04 发行说明](https://discourse.ubuntu.com/t/ubuntu-24-04-lts-noble-numbat-release-notes/39890)：命名 unconfined profile 可显式增加 userns 权限。
- [Ubuntu user namespace 限制说明](https://discourse.ubuntu.com/t/understanding-apparmor-user-namespace-restriction/58007)：创建 namespace 与其中 capability 使用由策略分别控制。
- [Docker AppArmor 文档](https://docs.docker.com/engine/security/apparmor/)：已加载命名 profile 可按容器选择和卸载。
- [Compose 合并规则](https://docs.docker.com/reference/compose-file/merge/)与[Harbor v0.22.0 Docker 实现](https://github.com/harbor-framework/harbor/blob/v0.22.0/src/harbor/environments/docker/docker.py)：解释替代 overlay 的要求。
- [先前只读审查](../harbor-scope-review-20261003.md)：原始拒绝链路、源码定位、候选边界和输入哈希。

候选名称、文件内容及诊断形状属于 Agent Self-Claimed。本目录只有这三个文件；没有执行脚本或预先安装策略。
