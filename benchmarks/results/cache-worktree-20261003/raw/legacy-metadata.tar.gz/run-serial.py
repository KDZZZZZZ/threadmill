#!/usr/bin/python3
"""Frozen external 48-row plan; default action validates identity only."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run(*argv):
    return subprocess.check_output([str(arg) for arg in argv], text=True).strip()


def git(repo, *args):
    return run("git", "-c", "safe.directory=" + str(repo), "-C", repo, *args)


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def preflight(expected_sha):
    require(os.geteuid() == 0, "requires the registered root launcher")
    path = BASE / "preregistration.json"
    require(sha(path) == expected_sha, "preregistration SHA256 differs")
    plan = json.loads(path.read_text())
    require(plan["expected_rows"] == 48 and plan["slots"] == 8, "fixed row count/slots differ")
    for path, expected in plan["files_sha256"].items():
        require(sha(path) == expected, "frozen input differs: " + path)
    project = Path(plan["project"])
    provenance = json.loads(Path(plan["provenance"]).read_text())
    require(git(project, "rev-parse", "HEAD") == provenance["template_main_commit"], "template commit differs")
    require(not git(project, "status", "--porcelain"), "template checkout is dirty")
    git(project, "merge-base", "--is-ancestor", provenance["template_main_commit"], "origin/main")
    clone = Path(provenance["clone"])
    require((clone / ".git").is_dir(), "bridge must remain an ordinary clone")
    require(git(clone, "rev-parse", "HEAD") == provenance["bridge_commit"], "bridge commit differs")
    require(not git(clone, "status", "--porcelain"), "bridge checkout is dirty")
    for name, expected in provenance["runtime_objects"].items():
        require(git(clone, "rev-parse", "HEAD:" + name) == expected, "old runtime object differs: " + name)
    require(git(clone, "diff", "--name-only", provenance["runtime_base"], "HEAD").splitlines() ==
            ["cmd/tmlegacy/audit.go", "cmd/tmlegacy/main.go", "cmd/tmlegacy/trace.go"], "bridge scope differs")
    sys.path.insert(0, str(project / "benchmarks/overlay-runtime"))
    from launch import lower_backing, overlay_mounts
    upper = Path(plan["upper_root"])
    observed = json.loads(run("findmnt", "-J", "-T", upper))["filesystems"][0]
    storage = json.loads((BASE / "storage-identity.json").read_text())
    expected_mount = storage["upper"]["mount"]["filesystems"][0]
    require(all(observed[key] == expected_mount[key] for key in ("target", "source", "fstype")), "upper filesystem differs")
    require(not overlay_mounts(upper), "legacy Overlay mounts present in parent namespace")
    require(not (BASE / "driver-status.json").exists(), "this formal round has already started; no automatic rerun")
    expected_rows = []
    for phase in plan["phases"]:
        fixture = Path(phase["fixture"])
        require(git(fixture, "rev-parse", "HEAD") == phase["fixture_commit"], "fixture commit differs")
        require(not git(fixture, "status", "--porcelain"), "fixture checkout is dirty")
        require(git(fixture, "config", "--get", "gc.auto") == "0", "fixture gc.auto differs")
        root, output = Path(phase["root"]), Path(phase["output"])
        require(root.is_dir() and not any(root.iterdir()), "upper phase directory is not fresh")
        require(not output.exists(), "phase output already exists")
        lower = storage["lowers"][phase["name"]]
        require(lower_backing(phase["lower"], root) == lower["backing"], "lower backing differs")
        mount = json.loads(run("findmnt", "-J", "-T", phase["lower"]))["filesystems"][0]
        expected = lower["mount"]["filesystems"][0]
        require(all(mount[key] == expected[key] for key in ("target", "source", "fstype")), "lower mount differs")
        usage = os.statvfs(phase["lower"])
        sample = lower["physical_registration_sample"]
        require((usage.f_blocks - usage.f_bfree) * usage.f_frsize == sample["df_used_bytes"], "lower allocation changed")
        require(run("du", "--summarize", "--block-size=1", "--", phase["lower"]) == sample["fixture_du_raw"], "lower du changed")
        for width in plan["widths"]:
            for repeat in range(1, plan["repeats"] + 1):
                expected_rows.append({"fixture": phase["name"], "width": width, "repeat": repeat})
    require(plan["row_order"] == expected_rows and len(expected_rows) == 48, "row ordering differs")
    return plan, {"checked_utc": now(), "preregistration_sha256": expected_sha, "identity_preflight": "passed",
                  "expected_rows": 48, "measurements_started": False, "euid": os.geteuid()}


def execute(plan, identity):
    status_path = BASE / "driver-status.json"
    status = {"started_utc": now(), "preregistration_sha256": identity["preregistration_sha256"],
              "serial": True, "expected_rows": 48, "completed_rows": 0, "complete": False, "phases": []}
    with status_path.open("x") as stream:
        json.dump(status, stream, indent=2)
        stream.write("\n")

    def save():
        temporary = BASE / "driver-status.tmp"
        temporary.write_text(json.dumps(status, indent=2) + "\n")
        temporary.replace(status_path)

    def interrupted(signum, _frame):
        raise SystemExit(128 + signum)

    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        for phase in plan["phases"]:
            output = Path(phase["output"])
            output.mkdir()
            current = {"name": phase["name"], "started_utc": now(), "argv": phase["argv"]}
            status["phases"].append(current)
            save()
            print(json.dumps({"phase_started": phase["name"], "expected_rows": 24}), flush=True)
            with (output / "driver.log").open("x") as log:
                process = subprocess.Popen(phase["argv"], cwd=plan["project"],
                                           env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "GIT_OPTIONAL_LOCKS": "0"},
                                           stdout=log, stderr=subprocess.STDOUT)
                try:
                    current["pid"] = process.pid
                    save()
                    current["exit_code"] = process.wait()
                finally:
                    if process.poll() is None:
                        process.kill()
                    process.wait()
            current["ended_utc"] = now()
            finals = [output / (plan["backend"] + f"-w{width}-r{repeat}.json")
                      for width in plan["widths"] for repeat in range(1, plan["repeats"] + 1)]
            current["completed_rows"] = sum(path.exists() for path in finals)
            status["completed_rows"] += current["completed_rows"]
            save()
            require(current["exit_code"] == 0, "matrix failed; evidence retained; no new fixture started")
            summary = json.loads((output / "summary.json").read_text())
            require(summary["complete"] is True and current["completed_rows"] == 24, "matrix did not complete all 24 rows")
            print(json.dumps({"phase_finished": phase["name"], "completed_rows": status["completed_rows"]}), flush=True)
        status["complete"] = status["completed_rows"] == 48
    except BaseException as error:
        status["stopped_on_failure"] = repr(error)
        raise
    finally:
        status["ended_utc"] = now()
        save()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--registration-sha256", required=True)
    parser.add_argument("--execute", action="store_true", help="run only after the sole hardware worker finishes the primary continuation")
    args = parser.parse_args()
    plan, identity = preflight(args.registration_sha256)
    print(json.dumps(identity), flush=True)
    if args.execute:
        execute(plan, identity)


if __name__ == "__main__":
    main()
