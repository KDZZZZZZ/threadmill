# Legacy bridge validation — 2026-10-03

Code: `bench/legacy-overlay` / `e177fa04559275ee2a7604f4513a887df23c9c44`, `/home/oops/repo/threadmill-legacy-overlay`.

Original shared harness baseline: 6 tests GREEN. Tests-only public success-row check failed while the new CLI was absent. The new consistent `error` + zero `errors` regression then failed against the draft, and passed after the validator guard. Native first run exposed the thread-local Linux children observer and ESRCH race; corrected observer/vanished-process handling passed on both fixtures.

Final: `shared-tests-final.log` (7 PASS), `public-native-final.log` (25 PASS, no skips), `native-ipython.log` (3 native PASS), `native-race.log` (real two-agent race binary checkpoint/restore PASS). `go vet -p 2 ./cmd/tmlegacy` passed under installed Go 1.24.2, GOMAXPROCS=2, GOTOOLCHAIN=local, GOWORK=off. Build metadata and old objects in `validated-provenance.json`; the actual candidate bridge revision is `928e58e`, only the 3 added `cmd/tmlegacy` files differ from the old runtime. Formal prepare must run again after the PR is merged; candidate binaries are not formal artifacts.

Synthetic and IPython `*-smoke*.json` preserve replay, physical samples, audit, and live-namespace cleanup evidence. Each used the first two agents of the frozen width-64 trace without changing those agents' operations. These are method checks executed while other nonformal tests were allowed, not performance or capacity results. Audit happened after the physical retained sample and both final validators returned zero errors. Synthetic uses the initial f933e80 bridge; IPython uses the comment-only 928e58e revision.

Dedicated readonly lowers are loop33/loop34, named in `lowers.json`; hashes/allocation stayed unchanged after tests in `lower-and-parent-mount-check.json`. Their images are on host ext4 outside the dedicated Btrfs upper. Parent namespace has no legacy native Overlay mounts. Idle 2-agent sampled checkpoint directories are `runtime-volume/legacy-sampled-{synthetic,ipython}`; they are kept for review. All unit/native temporary directories were cleaned. The interrupted primary `threadmill-external-w576-r3` directory was not touched.

To rerun (only outside formal timing):

```sh
python3 -m unittest discover -s benchmarks/pi-runtime -p 'test_*.py'
sudo -n env TMLEGACY_SEAM_MANIFEST=/home/oops/evals/threadmill-cache-bench/legacy-validation-20261003/validated-native-synthetic.json python3 -m unittest discover -s benchmarks/overlay-runtime -p 'test_public_seams.py'
```

Formal build/matrix commands are in `benchmarks/overlay-runtime/README.md`. Root owns independent review, PR integration, the fixed formal build/registration, and the sole-worker 48-row schedule. No formal historical rows have been run.
