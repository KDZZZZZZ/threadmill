#!/usr/bin/env python3
"""Run three audit-legacy CLI rejection checks after the real matrix finishes.

Creates temporary file symlinks, never copies a result tree or writes through
a symlink. The positive 48-row audit is deliberately a separate root action.
Run only in the sole idle hardware window; completion checks below do not
detect unrelated work on the host. --output must be a new directory.
"""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile

FIRST_ROW = "synthetic/threadmill-historical98-overlay-external-w64-r1.json"
ROOT_FILES = ("preregistration.json", "supervision-registration.json", "storage-identity.json",
              "tmlegacy-provenance.json", "run-serial.py", "driver-status.json", "supervisor.json")


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("raw", "primary-raw", "project", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--audit", type=Path, default=Path(__file__).with_name("audit-legacy.py"))
    args = parser.parse_args()
    raw, output, audit = args.raw.resolve(), args.output.resolve(), args.audit.resolve()
    driver = json.loads((raw / "driver-status.json").read_text())
    original_supervisor = (raw / "supervisor.json").read_bytes()
    proof = json.loads(original_supervisor)
    require(driver["complete"] is True and driver["completed_rows"] == driver["expected_rows"] == 48
            and "stopped_on_failure" not in driver, "legacy matrix must finish before CLI checks")
    require(proof["complete"] is True and proof["exit_code"] == proof["runner"]["returncode"] == 0
            and not proof["error"] and not proof["stop_signal"] and proof["subreaper"] is True,
            "legacy supervisor must finish successfully")
    cleanup = proof["cleanup"]
    require(cleanup["trigger"] == "runner_exit" and cleanup["clean"] is True
            and not any(cleanup[k] for k in ("live_descendants", "signals", "remaining", "errors")),
            "legacy supervisor must finish without live-leftover cleanup")
    output.mkdir(parents=True, exist_ok=False)
    checks = []

    for name in ("missing-first-final", "wrong-supervisor-command", "existing-output"):
        with tempfile.TemporaryDirectory(prefix=name + "-", dir=output) as temporary:
            view = Path(temporary) / "legacy"
            view.mkdir()
            for relative in ROOT_FILES:
                (view / relative).symlink_to(raw / relative)
            # Only the two flat evidence directories; never traverse old-source or caches.
            for fixture in ("synthetic", "ipython"):
                (view / fixture).mkdir()
                for source in (raw / fixture).iterdir():
                    if source.is_file():
                        (view / fixture / source.name).symlink_to(source)
            destination = Path(temporary) / "audit-output"
            if name == "missing-first-final":
                target = view / FIRST_ROW
                require(target.is_symlink(), "expected a temporary final-row symlink")
                target.unlink()
                markers = ("FileNotFoundError", Path(FIRST_ROW).name)
            elif name == "wrong-supervisor-command":
                target = view / "supervisor.json"
                require(target.is_symlink(), "expected a temporary supervisor symlink")
                target.unlink()
                changed = json.loads(original_supervisor)
                changed["command"] = ["intentional-negative-command"]
                target.write_text(json.dumps(changed) + "\n")
                markers = ("supervised driver differs",)
            else:
                destination.mkdir()
                (destination / "preserve.txt").write_text("do not overwrite\n")
                markers = ("FileExistsError", str(destination))
            command = [sys.executable, str(audit), "--raw", str(view),
                       "--primary-raw", str(args.primary_raw.resolve()), "--project", str(args.project.resolve()),
                       "--output", str(destination)]
            timed_out = False
            try:
                result = subprocess.run(command, text=True, capture_output=True, timeout=60)
                code, stdout, stderr = result.returncode, result.stdout, result.stderr
            except subprocess.TimeoutExpired as error:
                timed_out = True
                code = None
                stdout = (error.stdout or b"").decode(errors="replace")
                stderr = (error.stderr or b"").decode(errors="replace")
            (output / (name + ".stdout.log")).write_text(stdout)
            (output / (name + ".stderr.log")).write_text(stderr)
            unchanged = name != "existing-output" or (
                sorted(path.name for path in destination.iterdir()) == ["preserve.txt"]
                and (destination / "preserve.txt").read_text() == "do not overwrite\n")
            passed = (code is not None and code != 0 and not (destination / "summary.json").exists()
                      and all(marker in stderr for marker in markers) and unchanged)
            checks.append(dict(name=name, command=command, returncode=code, timed_out=timed_out,
                               no_success_summary=not (destination / "summary.json").exists(),
                               expected_error_markers=list(markers), output_preserved=unchanged, passed=passed,
                               stdout=name + ".stdout.log", stderr=name + ".stderr.log"))

    require((raw / "supervisor.json").read_bytes() == original_supervisor, "source supervisor changed during checks")
    report = dict(audit_sha256=hashlib.sha256(audit.read_bytes()).hexdigest(),
                  validator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  source_supervisor_sha256=hashlib.sha256(original_supervisor).hexdigest(),
                  checks=checks, passed=all(check["passed"] for check in checks),
                  scope="Three negative public CLI checks only; the positive full audit is separate.")
    (output / "validation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(dict(checks=len(checks), passed=report["passed"], output=str(output))))
    require(report["passed"], "a negative case did not fail for its intended reason; inspect saved CLI logs")


if __name__ == "__main__":
    main()
